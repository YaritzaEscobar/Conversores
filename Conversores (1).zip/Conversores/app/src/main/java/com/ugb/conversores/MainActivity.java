package com.ugb.conversores;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TabWidget;
import android.text.TextUtils;

public class MainActivity extends AppCompatActivity {
    TabHost tbh;
    Spinner spn, spnAlm, spnMon, spnMas, spnVol, spnTie;
    TextView tempVal, tempValAlm, tempValMon, tempValMas, tempValVol, tempValTie;
    Button btn, btnAlm, btnMon, btnMas, btnVol, btnTie;
    conversores miObj = new conversores();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //cambiar color barra de estado
        cambiarColorBarraEstado(getResources().getColor(R.color.gray60));


        tbh = findViewById(R.id.tbhConversores);
        tbh.setup();

        tbh.addTab(tbh.newTabSpec("longitud").setIndicator("LONGITUD").setContent(R.id.tabLongitud));
        tbh.addTab(tbh.newTabSpec("almacenamiento").setIndicator("ALMACENAMIENTO").setContent(R.id.tabAlmacenamiento));
        tbh.addTab(tbh.newTabSpec("monedas").setIndicator("MONEDAS").setContent(R.id.tabMonedas));
        tbh.addTab(tbh.newTabSpec("masa").setIndicator("MASA").setContent(R.id.tabMasa));
        tbh.addTab(tbh.newTabSpec("volumen").setIndicator("VOLUMEN").setContent(R.id.tabVolumen));
        tbh.addTab(tbh.newTabSpec("tiempo").setIndicator("TIEMPO").setContent(R.id.tabTiempo));
        tbh.addTab(tbh.newTabSpec("transferencia").setIndicator("TRANSFERENCIA DE DATOS").setContent(R.id.tabTransfDatos));


        // Obtener el TabWidget personalizado y habilitar el desplazamiento horizontal
        TabWidget tabWidget = tbh.getTabWidget();
        tabWidget.setStripEnabled(false); // Desactivar la tira indicadora
        tabWidget.setShowDividers(TabWidget.SHOW_DIVIDER_NONE); // Ocultar los divisores

        btn = findViewById(R.id.btnLongitudConvertir);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Longitud
                spn = findViewById(R.id.spnLongitudDe);
                int de = spn.getSelectedItemPosition();

                spn = findViewById(R.id.spnLongitudA);
                int a = spn.getSelectedItemPosition();

                tempVal = findViewById(R.id.txtLongitudCantidad);
                double cantidad = Double.parseDouble(tempVal.getText().toString());

                double resp = miObj.convertir(0, de, a, cantidad);
                Toast.makeText(getApplicationContext(), "Respuesta: "+ resp, Toast.LENGTH_LONG).show();

            }
        });

        //Almacenamiento
        btnAlm = findViewById(R.id.btnAlmacenamientoConvertir);
        btnAlm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                spnAlm = findViewById(R.id.spnAlmacenamientoDe);
                int de = spnAlm.getSelectedItemPosition();

                spnAlm = findViewById(R.id.spnAlmacenamientoA);
                int a = spnAlm.getSelectedItemPosition();

                tempValAlm = findViewById(R.id.txtAlmacenamientoCantidad);
                double cantidad = Double.parseDouble(tempValAlm.getText().toString());

                double respAlm = miObj.convertir(1, de, a, cantidad);
                Toast.makeText(getApplicationContext(), "Respuesta: "+ respAlm, Toast.LENGTH_LONG).show();

            }
        });

        //Monedas
        btnMon = findViewById(R.id.btnMonedasConvertir);
        btnMon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                spnMon = findViewById(R.id.spnMonedasDe);
                int de = spnMon.getSelectedItemPosition();

                spnMon = findViewById(R.id.spnMonedasA);
                int a = spnMon.getSelectedItemPosition();

                tempValMon = findViewById(R.id.txtMonedasCantidad);
                double cantidad = Double.parseDouble(tempValMon.getText().toString());

                double respMon = miObj.convertir(2, de, a, cantidad);
                Toast.makeText(getApplicationContext(), "Respuesta: "+ respMon, Toast.LENGTH_LONG).show();

            }
        });

        //Masa
        btnMas = findViewById(R.id.btnMasaConvertir);
        btnMas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                spnMas = findViewById(R.id.spnMasaDe);
                int de = spnMas.getSelectedItemPosition();

                spnMas = findViewById(R.id.spnMasaA);
                int a = spnMas.getSelectedItemPosition();

                tempValMas = findViewById(R.id.txtMasaCantidad);
                double cantidad = Double.parseDouble(tempValMas.getText().toString());

                double respMas = miObj.convertir(2, de, a, cantidad);
                Toast.makeText(getApplicationContext(), "Respuesta: "+ respMas, Toast.LENGTH_LONG).show();

            }
        });

        //Volumen
        btnMon = findViewById(R.id.btnMonedasConvertir);
        btnMon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                spnMon = findViewById(R.id.spnMonedasDe);
                int de = spnMon.getSelectedItemPosition();

                spnMon = findViewById(R.id.spnMonedasA);
                int a = spnMon.getSelectedItemPosition();

                tempValMon = findViewById(R.id.txtMonedasCantidad);
                double cantidad = Double.parseDouble(tempValMon.getText().toString());

                double respMon = miObj.convertir(2, de, a, cantidad);
                Toast.makeText(getApplicationContext(), "Respuesta: "+ respMon, Toast.LENGTH_LONG).show();

            }
        });



    } //


    private void cambiarColorBarraEstado(int color) {
        // Verificar si la versión del SDK es Lollipop o superior
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(color);
        }
    } //fin cambiar colorbarraestado

    class conversores{
        double[][] valores = {
                {1, 100, 39.3701, 3.28084, 1.193, 1.09361, 0.001, 0.000621371}, //longitud
                {1, 0.001, 0.000001, 0.000000001, 1000, 1000000, 0.000000001, 0.000001, 0.008, 8}, //Almacenamiento
                {1, 0.92, 7.86, 24.62, 36.56, 8.75, 535.14, 145.52, 83.32, 0.79}, //Monedas
                {1, 0.453592, 453.592, 0.000453592, 453592, 453600000, 0.000446429, 0.0005, 0.0714286, 16}, //Masa
                {1, 0.264172, 1.05669, 2.11338, 4.16667, 33.814, 67.628, 202.884, 0.001, 1000}, //Volumen
                {1, 60, 0.0166667, 0.000694444, 0.000099206, 0.000022831, 0.0000019026, 0.00000019026, 0.00000001903, 60000}, //Tiempo
                {}  //Transferencia de datos
        };
        public double convertir(int opcion, int de, int a, double cantidad){
            return valores[opcion][a] / valores[opcion][de] * cantidad;
        }


    }

}